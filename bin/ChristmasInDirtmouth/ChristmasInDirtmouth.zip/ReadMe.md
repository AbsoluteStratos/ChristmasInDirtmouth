# ChristmasInDirtmouth

A mod for the game Hollow Knight.


To show logs:
https://hk-modding.github.io/api/articles/logs.html#in-game-console